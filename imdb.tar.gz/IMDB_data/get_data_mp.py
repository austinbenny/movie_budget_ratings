from imdb import IMDb
import pandas as pd
import numpy as np
import time
import multiprocessing as mp


def get_info(index):
    
    
    size=len(inputs)
    row=[np.nan]*size
    current_movie=ia.get_movie(imdb_id[index])
    
    if (ia.get_movie(imdb_id[index]).get('box office')==None) or (len(ia.get_movie(imdb_id[index]).get('box office'))<3) or (ia.get_movie(imdb_id[index])['box office'].get('Opening Weekend United States')==None):
        
        return row
        
    else:
         
        col=0
        for wants in inputs:
            
            if wants =='Budget':
                budget = current_movie['box office'][wants]
                budget=budget.split(' ', 1)[0]
                chars_remove='$,'
                for character in chars_remove:
                    budget = budget.replace(character, '')
                row[col]=float(budget)
            
            elif wants == 'Cumulative Worldwide Gross':
                gross = current_movie['box office'][wants]
                gross=gross.split(' ', 1)[0]
                chars_remove='$,'
                for character in chars_remove:
                    gross = gross.replace(character, '')
                row[col]=float(gross)
                
            elif wants == 'Opening Weekend United States':
                opening=current_movie['box office'][wants]
                opening=opening.split(' ', 1)[0]
                chars_remove='$,'
                for character in chars_remove:
                    opening = opening.replace(character, '')
                row[col]=float(opening)
            
            elif wants == 'runtimes':
                row[col]=current_movie[wants][0]
            
            elif wants == 'title':
                row[col]=title[index]
            
            else:
                row[col]=current_movie[wants]
                
            col+=1      
            
        return row
    
def massage_df(path):
    df=pd.read_csv(path)
    # replace nan and inf
    df.replace([np.inf, -np.inf], np.nan)
    df=df.dropna()
    # reset the index
    df.reset_index(drop=True, inplace=True)
    return df

path = '/Users/austinbenny/Documents/python/movie budget ratings/IMDB_data/essential_imdb.csv'
df=massage_df(path)

global imdb_id
imdb_id=[df.loc[s,'imdb_id'].replace('tt','') for s in range(len(df))]

global title
title=df.loc[:,'title']

global inputs
inputs=['title','Cumulative Worldwide Gross','Budget','Opening Weekend United States','rating','runtimes','votes','aspect ratio']

global ia
ia=IMDb()

pool = mp.Pool(processes=mp.cpu_count())

final_len=10


start_time = time.time()
data=pool.map(get_info, range(0,final_len))
end_time = time.time()


df=pd.DataFrame.from_records(data)
df=df.dropna()
df.columns=inputs

shape=(len(data),len(data[0]))
print(shape)
print(end_time-start_time)